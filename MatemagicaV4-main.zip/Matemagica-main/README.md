# Matemágica
Link do portfólio: https://bytehub.wixsite.com/bytehub

Link do jogo: https://matemagica-steel.vercel.app/login

Protótipo do nosso sistema: https://drive.google.com/file/d/1gB14oSTiS2v55-_rz4HgStfeRYMxwH5i/view?usp=sharing
